package com.example.employee;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

public class punchInOut extends AppCompatActivity {
    EditText id,date;
    Button punchIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_punch_in_out);
        id=findViewById(R.id.selectedEmployee_id);
        date=findViewById(R.id.select_date);
        punchIn=findViewById(R.id.punchIn1);



    }
}